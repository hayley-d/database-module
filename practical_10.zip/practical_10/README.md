\### Access Database

```

http://localhost:7474

```



\## Task 1

--- 



\### Q1.4 Import csv Files

```

LOAD CSV WITH HEADERS FROM 'file:///people.csv' AS row CREATE(:Person{id: toInteger(row.id), name: row.name});

```



\### Q1.5 Show Current Graph View:

```

MATCH (n) RETURN n;

```



\### Q1.6 Import Follows csv

```

LOAD CSV WITH HEADERS FROM 'file:///follows.csv' AS row

MATCH (a:Person {name: row.person})

MATCH (b:Person {name: row.follows})

MERGE (a)-\[:FOLLOWS]->(b);

```



\### Q1.7

```

MATCH (n) RETURN n;

``` 





