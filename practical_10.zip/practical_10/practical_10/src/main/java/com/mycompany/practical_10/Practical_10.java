/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical_10;

/**
 *
 * @author 2002d
 */
public class Practical_10 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
